from django.test import TestCase

# Create your tests here.

print('yuan_alex_egon'.split('_',1))  # ['yuan', 'alex_egon']
print('yuan_alex_egon'.rsplit('_',1))  # ['yuan_alex', 'egon']

